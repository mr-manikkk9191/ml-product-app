import os, pandas as pd
from dotenv import load_dotenv
import openai
from pinecone import Pinecone

# Load the .env that sits next to Backend/main.py
load_dotenv(os.path.join(os.path.dirname(__file__), "..", "Backend", ".env"))

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PC_API_KEY = os.getenv("PINECONE_API_KEY")
INDEX_NAME = os.getenv("PINECONE_INDEX", "ml-project")

assert OPENAI_API_KEY, "OPENAI_API_KEY missing"
assert PC_API_KEY, "PINECONE_API_KEY missing"

openai.api_key = OPENAI_API_KEY
pc = Pinecone(api_key=PC_API_KEY)
index = pc.Index(INDEX_NAME)

def embed(txt: str):
    txt = (txt or "").replace("\n", " ")
    return openai.embeddings.create(model="text-embedding-3-small", input=[txt]).data[0].embedding

csv_path = os.path.join(os.path.dirname(__file__), "..", "Backend", "data", "products_sample.csv")
df = pd.read_csv(csv_path)

batch = []
for _, r in df.iterrows():
    text = f"{r.get('title','')} | {r.get('brand','')} | {r.get('description','')}"
    vec = embed(text)
    meta = {
        "title": r.get("title"),
        "brand": r.get("brand"),
        "price": float(r["price"]) if str(r.get("price","")).replace('.','',1).isdigit() else None,
        "category": r.get("category"),
        "description": r.get("description","")
    }
    batch.append({"id": str(r.get("uniq_id")), "values": vec, "metadata": meta})

# upsert in chunks of 100
for i in range(0, len(batch), 100):
    index.upsert(vectors=batch[i:i+100])

print("Upsert complete.")
