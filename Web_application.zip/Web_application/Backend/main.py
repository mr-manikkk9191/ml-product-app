# Backend/main.py
# ------------------------------------------------------------
# FastAPI backend for recommendation, analytics, and CV demo
# ------------------------------------------------------------

import os
import re
import json
import base64
from typing import List, Dict, Any, Optional

import numpy as np
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, Query, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from pinecone import Pinecone
from sklearn.cluster import KMeans

# LangChain (OpenAI wrappers)
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.messages import HumanMessage

# ----------------------------
# Load environment
# ----------------------------
ENV_PATH = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(ENV_PATH)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_INDEX = os.getenv("PINECONE_INDEX", "ml-project1")

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY missing in Backend/.env")
if not PINECONE_API_KEY:
    raise RuntimeError("PINECONE_API_KEY missing in Backend/.env")

# Make sure the OpenAI key is visible to LangChain
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# ----------------------------
# Clients
# ----------------------------
# LangChain embedding + chat clients
lc_embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key=OPENAI_API_KEY,
)
lc_chat = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.4,
    api_key=OPENAI_API_KEY,
)

# Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY)
index = pc.Index(PINECONE_INDEX)

# ----------------------------
# FastAPI app & CORS
# ----------------------------
app = FastAPI(title="Product Recommendation API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------------------
# Schemas
# ----------------------------
class RecommendRequest(BaseModel):
    query: str
    top_k: int = 10
    max_price: Optional[float] = None
    category: Optional[str] = None

class Recommendation(BaseModel):
    id: str
    score: float
    title: str
    brand: Optional[str] = None
    price: Optional[float] = None
    category: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    gen_description: Optional[str] = None

class GroupRequest(BaseModel):
    query: str
    top_n: int = 60
    k: int = 3
    max_price: Optional[float] = None
    category: Optional[str] = None

class ImageUrlPayload(BaseModel):
    url: str

# ----------------------------
# Helpers
# ----------------------------
def embed_text(text: str) -> List[float]:
    """Create an embedding vector (via LangChain OpenAIEmbeddings)."""
    return lc_embeddings.embed_query((text or "").replace("\n", " "))

def passes_filters(md: Dict[str, Any], max_price: Optional[float], category: Optional[str]) -> bool:
    """Client-side metadata filtering (safety net)."""
    if max_price is not None:
        p = md.get("price")
        try:
            if p is None or float(p) > float(max_price):
                return False
        except Exception:
            return False

    if category:
        cat_text = str(md.get("categories") or md.get("category") or "").lower()
        if category.lower() not in cat_text:
            return False

    return True

def gen_marketing_copy(title: str, description: str = "", brand: str = "", category: str = "") -> str:
    """Generate a short 2-sentence marketing blurb (LangChain ChatOpenAI)."""
    prompt = f"""You are a concise product copywriter.
Write an engaging 2-sentence blurb for the product below.
Avoid hype; be specific and helpful.

Title: {title}
Brand: {brand}
Category: {category}
Details: {description}
Blurb:"""
    try:
        msg = lc_chat.invoke(prompt)
        return (msg.content or "").strip()
    except Exception:
        return ""

def _get_matches(res: Any) -> List[Dict[str, Any]]:
    """Pinecone Python client may return dict-like or object-like results."""
    if isinstance(res, dict):
        return res.get("matches", []) or []
    return getattr(res, "matches", []) or []

# ----------------------------
# Routes
# ----------------------------
@app.get("/")
def root():
    return {"status": "ok", "index": PINECONE_INDEX}

@app.get("/health")
def health():
    """Basic readiness check."""
    try:
        _ = index.describe_index_stats()
        _ = lc_embeddings.embed_query("ping")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ---------- Recommendation ----------
@app.post("/recommend", response_model=List[Recommendation])
def recommend(req: RecommendRequest):
    """
    1) Embed query
    2) Query Pinecone
    3) Client-side filters
    4) GenAI blurb
    """
    qvec = embed_text(req.query)

    pine_filter: Dict[str, Any] = {}
    # Example if you saved numerics/lists:
    # if req.max_price is not None:
    #     pine_filter["price_num"] = {"$lte": float(req.max_price)}
    # if req.category:
    #     pine_filter["categories"] = {"$contains": req.category}

    res = index.query(
        vector=qvec,
        top_k=req.top_k,
        include_metadata=True,
        filter=pine_filter or None,
    )

    out: List[Recommendation] = []
    for m in _get_matches(res):
        md = m.get("metadata", {}) or {}
        if not passes_filters(md, req.max_price, req.category):
            continue

        item_title = md.get("title") or ""
        item_desc  = md.get("description") or ""
        item_brand = md.get("brand") or ""
        item_cat   = md.get("categories") or md.get("category") or ""
        item_img   = md.get("image_url") or md.get("images") or None

        blurb = gen_marketing_copy(item_title, item_desc, item_brand, item_cat)

        out.append(Recommendation(
            id=str(m.get("id")),
            score=float(m.get("score", 0.0)),
            title=item_title,
            brand=item_brand,
            price=md.get("price"),
            category=item_cat,
            description=item_desc,
            image_url=item_img,
            gen_description=blurb,
        ))
    return out

# ---------- Group similar ----------
@app.post("/group")
def group_similar(req: GroupRequest):
    """Cluster top-N results into k groups using their vectors."""
    qvec = embed_text(req.query)

    res = index.query(
        vector=qvec,
        top_k=req.top_n,
        include_values=True,
        include_metadata=True,
    )

    matches = _get_matches(res)
    vecs: List[np.ndarray] = []
    items: List[Dict[str, Any]] = []

    for m in matches:
        values = m.get("values")
        if values is None:
            continue

        md = m.get("metadata", {}) or {}
        items.append({
            "id": str(m.get("id")),
            "score": float(m.get("score", 0.0)),
            "title": md.get("title"),
            "brand": md.get("brand"),
            "price": md.get("price"),
            "category": md.get("categories") or md.get("category"),
            "image_url": md.get("image_url") or md.get("images"),
            "description": md.get("description"),
        })
        vecs.append(np.array(values, dtype=np.float32))

    if len(vecs) < max(2, req.k):
        return {"clusters": [{"label": "All", "count": len(items), "items": items}]}

    X = np.stack(vecs)
    k = min(req.k, len(items))
    km = KMeans(n_clusters=k, n_init="auto", random_state=42)
    labels = km.fit_predict(X)

    clusters: Dict[int, List[Dict[str, Any]]] = {}
    for lab, it in zip(labels, items):
        clusters.setdefault(int(lab), []).append(it)

    def short_label(group: List[Dict[str, Any]]) -> str:
        brands = [it.get("brand") for it in group if it.get("brand")]
        if brands:
            return brands[0]
        cats = []
        for it in group:
            c = it.get("category")
            if isinstance(c, str):
                cats.append(c.split(">")[-1].strip())
        return cats[0] if cats else "Group"

    out_clusters = []
    for gidx, group in clusters.items():
        out_clusters.append({
            "label": short_label(group),
            "count": len(group),
            "items": group[:10],
        })

    out_clusters.sort(key=lambda c: c["count"], reverse=True)
    return {"clusters": out_clusters}

# ---------- Analytics ----------
@app.get("/analytics")
def analytics(
    category: Optional[str] = Query(None, description="substring match against categories text"),
    brand: Optional[str]   = Query(None, description="substring match against brand"),
    price_min: Optional[float] = Query(None),
    price_max: Optional[float] = Query(None),
    top_n: int = Query(10, ge=3, le=30, description="how many top buckets/brands to return"),
):
    """
    Returns summary + chart-ready series (filterable).
    - Filters: category/brand substring, min/max price
    - Series: top_categories, top_brands, price_histogram, price_scatter, gallery
    """
    csv_path = os.path.join(os.path.dirname(__file__), "data", "intern_data_ikarus.csv")
    df = pd.read_csv(csv_path)

    # --- robust numeric price ---
    def parse_price(x):
        if pd.isna(x):
            return np.nan
        s = str(x).replace(",", "")
        m = re.search(r"-?\d+(?:\.\d+)?", s)
        return float(m.group(0)) if m else np.nan

    if "price" in df.columns:
        df["price_num"] = df["price"].map(parse_price)
    else:
        df["price_num"] = np.nan

    # ---- filters ----
    to_s = lambda v: str(v) if pd.notna(v) else ""

    if category:
        mask = df.get("categories").map(to_s).str.lower().str.contains(category.lower(), na=False)
        df = df[mask]

    if brand:
        mask = df.get("brand").map(to_s).str.lower().str.contains(brand.lower(), na=False)
        df = df[mask]

    if price_min is not None:
        df = df[df["price_num"] >= float(price_min)]
    if price_max is not None:
        df = df[df["price_num"] <= float(price_max)]

    # ---- summary ----
    total = int(len(df))
    distinct_brands = int(df["brand"].nunique()) if "brand" in df.columns else 0

    # ---- top categories ----
    def coarse(v):
        if pd.isna(v): return None
        return str(v).split(">")[-1].strip()

    top_cats = []
    if "categories" in df.columns and not df.empty:
        cats = df["categories"].map(coarse).dropna()
        vc = cats.value_counts().head(top_n)
        top_cats = [{"name": k, "count": int(v)} for k, v in vc.items()]

    # ---- top brands ----
    top_brands = []
    if "brand" in df.columns and not df.empty:
        vb = df["brand"].dropna().astype(str).value_counts().head(top_n)
        top_brands = [{"name": k, "count": int(v)} for k, v in vb.items()]

    # ---- price stats + histogram ----
    ps = df["price_num"].dropna()
    if ps.empty:
        stats = {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        hist = [{"range": "0-1", "count": 0, "x0": 0.0, "x1": 1.0}]
    else:
        stats = {
            "min": float(ps.min()),
            "max": float(ps.max()),
            "mean": float(ps.mean()),
            "median": float(ps.median()),
        }
        lo, hi = stats["min"], stats["max"]
        if lo == hi:
            lo, hi = lo - 1.0, hi + 1.0
        edges = np.linspace(lo, hi, 12)  # 11 buckets
        counts, edges = np.histogram(ps, bins=edges)
        hist = []
        for i in range(len(counts)):
            hist.append({
                "range": f"{edges[i]:.2f}-{edges[i+1]:.2f}",
                "count": int(counts[i]),
                "x0": float(edges[i]),
                "x1": float(edges[i+1]),
            })

    # ---- scatter (sample) ----
    scatter = []
    if not df.empty and "title" in df.columns:
        sample = df.loc[~df["price_num"].isna()].sample(
            min(400, df["price_num"].notna().sum()), random_state=42
        )
        for _, r in sample.iterrows():
            scatter.append({
                "price": float(r["price_num"]),
                "title_len": len(str(r.get("title") or "")),
                "brand": r.get("brand", ""),
            })

    # ---- gallery ----
    def first_img(val):
        if pd.isna(val): return None
        s = str(val)
        try:
            arr = json.loads(s.replace("'", '"'))
            if isinstance(arr, list) and arr:
                return arr[0]
        except Exception:
            pass
        m = re.search(r"https?://[^\s\'\",]+", s)
        return m.group(0) if m else None

    gallery = []
    for _, r in df.head(12).iterrows():
        gallery.append({
            "title": str(r.get("title", ""))[:120],
            "price": float(r["price_num"]) if pd.notna(r["price_num"]) else None,
            "brand": r.get("brand"),
            "category": r.get("categories") or r.get("category"),
            "image_url": first_img(r.get("image_url") or r.get("images")),
        })

    return {
        "summary": {"total_products": total, "distinct_brands": distinct_brands},
        "price_stats": stats,
        "top_categories": top_cats,
        "top_brands": top_brands,
        "price_histogram": hist,
        "price_scatter": scatter,
        "gallery": gallery,
    }

# ---------- Computer Vision (zero-shot) ----------
@app.post("/classify-image-file")
async def classify_image_file(file: UploadFile = File(...)):
    """
    Classify an uploaded image (zero-shot). Always returns 200 with ok=True/False.
    """
    try:
        content = await file.read()
        b64 = base64.b64encode(content).decode("utf-8")
        data_url = f"data:{file.content_type or 'image/png'};base64,{b64}"

        msg = HumanMessage(content=[
            {
                "type": "text",
                "text": (
                    "Classify this product photo into a simple category such as "
                    "'chair', 'table', 'sofa', 'lamp', 'storage rack', 'stool', 'cabinet', "
                    "'mat', 'decor', 'kitchen', 'outdoor', or 'other'. "
                    "Respond ONLY with compact JSON: "
                    '{"label":"<category>","confidence":<0-1 float>}'
                ),
            },
            {"type": "image_url", "image_url": {"url": data_url, "detail": "low"}},
        ])

        raw = lc_chat.invoke([msg]).content or ""
        m = re.search(r"\{.*\}", raw, flags=re.S)
        if m:
            try:
                obj = json.loads(m.group(0))
                label = str(obj.get("label", "unknown")).strip()
                conf = float(obj.get("confidence", 0.5))
                return {"ok": True, "label": label, "confidence": conf}
            except Exception:
                pass
        return {"ok": True, "label": raw.strip()[:64] or "unknown", "confidence": 0.5}

    except Exception as e:
        return {"ok": False, "error": str(e)}

@app.post("/classify-image-url")
def classify_image_url(payload: ImageUrlPayload):
    """
    Classify an image reachable by URL (zero-shot). Always returns 200 with ok=True/False.
    """
    try:
        url = payload.url.strip()

        msg = HumanMessage(content=[
            {
                "type": "text",
                "text": (
                    "Classify this product photo into a simple category such as "
                    "'chair', 'table', 'sofa', 'lamp', 'storage rack', 'stool', 'cabinet', "
                    "'mat', 'decor', 'kitchen', 'outdoor', or 'other'. "
                    "Respond ONLY with compact JSON: "
                    '{"label":"<category>","confidence":<0-1 float>}'
                ),
            },
            {"type": "image_url", "image_url": {"url": url, "detail": "low"}},
        ])

        raw = lc_chat.invoke([msg]).content or ""
        m = re.search(r"\{.*\}", raw, flags=re.S)
        if m:
            try:
                obj = json.loads(m.group(0))
                label = str(obj.get("label", "unknown")).strip()
                conf = float(obj.get("confidence", 0.5))
                return {"ok": True, "label": label, "confidence": conf}
            except Exception:
                pass
        return {"ok": True, "label": raw.strip()[:64] or "unknown", "confidence": 0.5}

    except Exception as e:
        return {"ok": False, "error": str(e)}
