import os
from dotenv import load_dotenv

load_dotenv()
print("OPENAI:", os.getenv("OPENAI_API_KEY"))
print("PINECONE:", os.getenv("PINECONE_API_KEY"))
exit()
