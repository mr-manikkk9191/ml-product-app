import axios from "axios";

const API =
  (import.meta.env?.VITE_API_URL
    ? String(import.meta.env.VITE_API_URL).replace(/\/$/, "")
    : "http://127.0.0.1:8000");

export const http = axios.create({
  baseURL: API,
  timeout: 20000,
});

// Recommendations
export async function getRecommendations({ query, top_k = 12, max_price, category }) {
  const payload = { query, top_k, max_price, category };
  const { data } = await http.post("/recommend", payload);
  return data;
}

// Analytics (filterable)
export async function getAnalytics(params = {}) {
  const { data } = await http.get("/analytics", { params });
  return data;
}

// CV: classify file blob
export async function classifyImageBlob(file) {
  const fd = new FormData();
  fd.append("file", file);
  const { data } = await http.post("/classify-image-file", fd, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

// CV: classify via image URL
export async function classifyImageUrl(url) {
  const { data } = await http.post("/classify-image-url", { url });
  return data;
}
