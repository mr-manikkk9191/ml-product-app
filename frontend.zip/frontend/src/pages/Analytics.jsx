// frontend/src/pages/Analytics.jsx
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { getAnalytics } from "../api/api";
import {
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Brush,
  ReferenceLine,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  ZAxis,
} from "recharts";

/* ---------------------- helpers ---------------------- */
const fmtUSD = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 2,
});

const COLORS = [
  "#60a5fa", "#34d399", "#fbbf24", "#f87171", "#a78bfa",
  "#2dd4bf", "#f472b6", "#22c55e", "#fb923c", "#06b6d4",
];

const wrapTick = (s, max = 14) => {
  if (!s) return "";
  const str = String(s);
  if (str.length <= max) return str;
  // try break on space
  const i = str.lastIndexOf(" ", max);
  if (i > 6) return str.slice(0, i) + "\n" + str.slice(i + 1);
  return str.slice(0, max) + "…";
};

/** Calculate short, human-readable insights for the summary box */
function computeInsights(d) {
  if (!d) return { bullets: [] };

  const bullets = [];
  const ps = d.price_stats ?? {};
  const hist = d.price_histogram ?? [];
  const cats = d.top_categories ?? [];
  const brands = d.top_brands ?? [];

  if (ps.mean != null && ps.median != null) {
    const tilt =
      ps.mean > ps.median * 1.15 ? "right-skewed (few expensive items)"
      : ps.mean < ps.median * 0.85 ? "left-skewed (many low-priced items)"
      : "fairly balanced";
    bullets.push(
      `Prices are ${tilt}. Avg ${fmtUSD.format(ps.mean)}; Median ${fmtUSD.format(ps.median)}.`
    );
  }

  if (hist.length) {
    const peak = [...hist].sort((a, b) => b.count - a.count)[0];
    bullets.push(`The densest price bucket is **${peak.range}**.`);
  }

  if (cats.length) {
    const top3 = cats.slice(0, 3).map((c) => c.name).join(", ");
    bullets.push(`Top categories: **${top3}**.`);
  }

  if (brands.length) {
    const maxBrand = brands[0]?.count ?? 0;
    if (maxBrand < 6) {
      bullets.push("Brand share is **fragmented** — no dominant brand.");
    } else {
      bullets.push(`Brand **${brands[0].name}** leads with ${brands[0].count} items.`);
    }
  }

  bullets.push(
    `You’re viewing **${d?.summary?.total_products ?? 0}** products from **${d?.summary?.distinct_brands ?? 0}** brands (after filters).`
  );

  return { bullets };
}

/* ---------------------- dark theme tokens ---------------------- */
const dark = {
  bgPage: "#0B1220",
  bgCard: "#0f172a",          // slate-900-ish
  border: "#1f2937",
  text: "#e5e7eb",
  textMuted: "#94a3b8",
  grid: "#334155",
  primary: "#60a5fa",
  success: "#34d399",
  accent: "#a78bfa",
};

const inputStyle = {
  padding: 10,
  border: `1px solid ${dark.border}`,
  borderRadius: 8,
  width: 220,
  background: "#0b1220",
  color: dark.text,
};

const pillBtn = (active) => ({
  padding: "8px 12px",
  border: `1px solid ${active ? dark.primary : dark.border}`,
  borderRadius: 12,
  background: active ? "rgba(96,165,250,0.15)" : "transparent",
  color: active ? dark.primary : dark.text,
  textDecoration: "none",
  fontWeight: 700,
});

/* ---------------------- components ---------------------- */
const Card = ({ title, children, right }) => (
  <div
    style={{
      border: `1px solid ${dark.border}`,
      borderRadius: 12,
      background: dark.bgCard,
      padding: 12,
    }}
  >
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        color: dark.text,
        marginBottom: 8,
        fontWeight: 700,
      }}
    >
      <span>{title}</span>
      {right}
    </div>
    {children}
  </div>
);

const Stat = ({ label, value, loading }) => (
  <div
    style={{
      border: `1px solid ${dark.border}`,
      borderRadius: 12,
      background: dark.bgCard,
      padding: 16,
      minWidth: 160,
    }}
  >
    <div style={{ fontSize: 12, color: dark.textMuted }}>{label}</div>
    {loading ? (
      <div
        style={{
          height: 22,
          width: 90,
          background: "#1e293b",
          borderRadius: 6,
          marginTop: 6,
        }}
      />
    ) : (
      <div style={{ fontSize: 22, fontWeight: 800, color: dark.text }}>{value}</div>
    )}
  </div>
);

const Empty = ({ msg = "No data" }) => (
  <div
    style={{
      height: 240,
      border: `1px dashed ${dark.border}`,
      background: "#0b1220",
      color: dark.textMuted,
      borderRadius: 12,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    {msg}
  </div>
);

/* ---------------------- page ---------------------- */
export default function Analytics() {
  const [category, setCategory] = useState("");
  const [brand, setBrand] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  // fetch with debounce
  useEffect(() => {
    let alive = true;
    const t = setTimeout(async () => {
      setLoading(true);
      setError("");
      try {
        const res = await getAnalytics({
          category: category || undefined,
          brand: brand || undefined,
          price_min: priceMin || undefined,
          price_max: priceMax || undefined,
          top_n: 12,
        });
        if (alive) setData(res);
      } catch {
        if (alive) setError("Failed to load analytics");
      } finally {
        if (alive) setLoading(false);
      }
    }, 280);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [category, brand, priceMin, priceMax]);

  const histForPie = useMemo(() => {
    if (!data?.price_histogram?.length) return [];
    return data.price_histogram.map((b, i) => ({
      name: b.range,
      value: b.count,
      color: COLORS[i % COLORS.length],
    }));
  }, [data]);

  const mean = data?.price_stats?.mean ?? 0;
  const median = data?.price_stats?.median ?? 0;

  const insights = computeInsights(data);

  /* --- recharts theme bits --- */
  const axisStyle = { stroke: dark.textMuted, fill: dark.textMuted, fontSize: 12 };
  const gridStyle = { stroke: dark.grid, strokeDasharray: "3 3" };
  const tooltipStyle = {
    backgroundColor: "#0b1220",
    border: `1px solid ${dark.border}`,
    borderRadius: 8,
    color: dark.text,
  };

  return (
    <div style={{ maxWidth: 1200, margin: "22px auto", padding: "0 16px", color: dark.text, background: dark.bgPage }}>
      {/* header tabs */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ fontWeight: 800, fontSize: 18, color: dark.text }}>📊 Analytics</div>
        </div>
        <Link to="/" style={pillBtn(false)}>🔎 Recommender</Link>
      </div>

      {/* filters */}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
        <input
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Filter: category contains…"
          style={inputStyle}
        />
        <input
          value={brand}
          onChange={(e) => setBrand(e.target.value)}
          placeholder="Filter: brand contains…"
          style={inputStyle}
        />
        <input
          value={priceMin}
          onChange={(e) => setPriceMin(e.target.value)}
          placeholder="Min price"
          style={{ ...inputStyle, width: 140 }}
        />
        <input
          value={priceMax}
          onChange={(e) => setPriceMax(e.target.value)}
          placeholder="Max price"
          style={{ ...inputStyle, width: 140 }}
        />
        <button
          onClick={() => {
            setCategory("");
            setBrand("");
            setPriceMin("");
            setPriceMax("");
          }}
          style={{
            padding: "10px 14px",
            border: `1px solid ${dark.border}`,
            borderRadius: 8,
            background: "#0b1220",
            color: dark.text,
            cursor: "pointer",
          }}
        >
          Reset
        </button>
      </div>

      {error && (
        <div
          style={{
            padding: 10,
            border: "1px solid #7f1d1d",
            background: "#1b0b0b",
            color: "#fecaca",
            borderRadius: 8,
            marginBottom: 12,
          }}
        >
          {error}
        </div>
      )}

      {/* top stats */}
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
        <Stat label="Total Products" value={data?.summary?.total_products ?? 0} loading={loading} />
        <Stat label="Distinct Brands" value={data?.summary?.distinct_brands ?? 0} loading={loading} />
        <Stat label="Avg Price" value={fmtUSD.format(mean)} loading={loading} />
        <Stat label="Median Price" value={fmtUSD.format(median)} loading={loading} />
      </div>

      {/* categories & brands */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card
          title="Top Categories"
          right={<span style={{ color: dark.textMuted, fontSize: 12 }}>wrap labels • brush to zoom</span>}
        >
          {data?.top_categories?.length ? (
            <>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={data.top_categories}>
                  <CartesianGrid {...gridStyle} />
                  <XAxis
                    dataKey="name"
                    interval={0}
                    tickFormatter={(t) => wrapTick(t, 12)}
                    tick={axisStyle}
                  />
                  <YAxis tick={axisStyle} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ color: dark.text }} />
                  <Bar dataKey="count" fill={dark.primary} radius={[6, 6, 0, 0]} />
                  <Brush dataKey="name" height={18} stroke={dark.primary} />
                </BarChart>
              </ResponsiveContainer>
              <Insight text={`Categories are topped by “${data.top_categories[0].name}”.`} />
            </>
          ) : (
            <Empty />
          )}
        </Card>

        <Card
          title="Top Brands"
          right={<span style={{ color: dark.textMuted, fontSize: 12 }}>wrap labels • brush to zoom</span>}
        >
          {data?.top_brands?.length ? (
            <>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={data.top_brands}>
                  <CartesianGrid {...gridStyle} />
                  <XAxis
                    dataKey="name"
                    interval={0}
                    tickFormatter={(t) => wrapTick(t, 12)}
                    tick={axisStyle}
                  />
                  <YAxis tick={axisStyle} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ color: dark.text }} />
                  <Bar dataKey="count" fill={dark.success} radius={[6, 6, 0, 0]} />
                  <Brush dataKey="name" height={18} stroke={dark.success} />
                </BarChart>
              </ResponsiveContainer>
              <Insight
                text={
                  data.top_brands[0]
                    ? `Brand leader: “${data.top_brands[0].name}” with ${data.top_brands[0].count} items.`
                    : "No dominant brand."
                }
              />
            </>
          ) : (
            <Empty />
          )}
        </Card>
      </div>

      {/* histogram & pie */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card title="Price Histogram">
          {data?.price_histogram?.length ? (
            <>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={data.price_histogram}>
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={dark.accent} stopOpacity={0.6} />
                      <stop offset="100%" stopColor={dark.accent} stopOpacity={0.05} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid {...gridStyle} />
                  <XAxis dataKey="range" tick={axisStyle} />
                  <YAxis tick={axisStyle} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Area
                    type="monotone"
                    dataKey="count"
                    stroke={dark.accent}
                    fillOpacity={1}
                    fill="url(#g1)"
                  />
                  <Brush dataKey="range" height={18} stroke={dark.accent} />
                </AreaChart>
              </ResponsiveContainer>
              <Insight
                text={`Most items cluster near ${
                  [...data.price_histogram].sort((a, b) => b.count - a.count)[0].range
                }.`}
              />
            </>
          ) : (
            <Empty />
          )}
        </Card>

        <Card title="Bucket Share (donut)">
          {histForPie.length ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={histForPie}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={3}
                >
                  {histForPie.map((e, i) => (
                    <Cell key={e.name} fill={e.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ color: dark.text }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <Empty />
          )}
        </Card>
      </div>

      {/* scatter */}
      <Card title="Price vs Title Length (sample)">
        {data?.price_scatter?.length ? (
          <ResponsiveContainer width="100%" height={320}>
            <ScatterChart>
              <CartesianGrid {...gridStyle} />
              <XAxis type="number" dataKey="price" name="Price" tick={axisStyle} />
              <YAxis type="number" dataKey="title_len" name="Title length" tick={axisStyle} />
              <ZAxis type="number" range={[60, 160]} />
              <Tooltip contentStyle={tooltipStyle} cursor={{ strokeDasharray: "3 3" }} />
              <Legend wrapperStyle={{ color: dark.text }} />
              <Scatter data={data.price_scatter} fill="#a78bfa" />
              <ReferenceLine
                x={mean}
                stroke="#f87171"
                strokeDasharray="4 4"
                label={{ value: `Mean ${fmtUSD.format(mean)}`, fill: dark.textMuted }}
              />
              <ReferenceLine
                x={median}
                stroke="#34d399"
                strokeDasharray="4 4"
                label={{ value: `Median ${fmtUSD.format(median)}`, fill: dark.textMuted }}
              />
            </ScatterChart>
          </ResponsiveContainer>
        ) : (
          <Empty />
        )}
        <Insight text="Longer titles don’t strongly correlate with price — bubbles spread fairly evenly." />
      </Card>

      {/* gallery */}
      <Card title="Sample Products (filtered)">
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))",
            gap: 12,
          }}
        >
          {(data?.gallery ?? []).map((g, i) => (
            <div
              key={i}
              style={{
                border: `1px solid ${dark.border}`,
                background: "#0b1220",
                borderRadius: 12,
                padding: 10,
              }}
            >
              <div
                style={{
                  height: 150,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "#0f172a",
                  borderRadius: 8,
                  marginBottom: 8,
                }}
              >
                <img
                  alt={g.title}
                  src={g.image_url || ""}
                  style={{ maxWidth: "100%", maxHeight: 150, objectFit: "contain" }}
                  loading="lazy"
                />
              </div>
              <div style={{ fontWeight: 700, marginBottom: 6, color: dark.text }}>
                {g.title}
              </div>
              <div style={{ color: dark.textMuted, fontSize: 12, marginBottom: 6 }}>
                {g.brand || "—"}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                <span style={{ color: dark.textMuted }}>
                  {g.category ? String(g.category).split(">").pop().trim() : "—"}
                </span>
                <span style={{ color: dark.text }}>{g.price != null ? fmtUSD.format(g.price) : "—"}</span>
              </div>
            </div>
          ))}
          {!data?.gallery?.length && <Empty msg="No products in this slice" />}
        </div>
      </Card>

      {/* --- Summary box --- */}
      <Card title="Key Takeaways">
        <ul style={{ color: dark.text, margin: 0, paddingLeft: 18, lineHeight: 1.7 }}>
          {insights.bullets.map((b, i) => (
            <li key={i} dangerouslySetInnerHTML={{ __html: b.replace(/\*\*(.*?)\*\*/g, "<b>$1</b>") }} />
          ))}
        </ul>
      </Card>
    </div>
  );
}

/* tiny helper for chart footnotes */
function Insight({ text }) {
  return (
    <div style={{ marginTop: 8, color: dark.textMuted, fontSize: 12 }}>
      🧠 <i>{text}</i>
    </div>
  );
}
