// frontend/src/App.jsx
import { useState } from "react";
import { Link } from "react-router-dom";
import { getRecommendations, classifyImageBlob, classifyImageUrl } from "./api/api";

function formatUsd(n){
  if (n == null || Number.isNaN(n)) return "";
  return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n);
}
function parseCats(c){
  if (!c) return [];
  try{
    const cleaned = String(c).replace(/^\s*\(/,"[").replace(/\)\s*$/ ,"]");
    const arr = JSON.parse(cleaned.replace(/'/g,'"'));
    return Array.isArray(arr)?arr.slice(0,3):[String(c)];
  }catch{
    return String(c).split(">").slice(0,3).map(s=>s.trim()).filter(Boolean);
  }
}
function firstImageUrl(val){
  if(!val) return null;
  const s=String(val);
  try{
    const arr=JSON.parse(s.replace(/'/g,'"'));
    if(Array.isArray(arr)&&arr.length&&/^https?:\/\//i.test(arr[0])) return arr[0];
  }catch{}
  const m=s.match(/https?:\/\/[^\s'",\]]+/i);
  return m?m[0]:null;
}

export default function App(){
  const [query,setQuery]=useState("wooden office chair");
  const [maxPrice,setMaxPrice]=useState("");
  const [category,setCategory]=useState("");
  const [loading,setLoading]=useState(false);
  const [results,setResults]=useState([]);
  const [error,setError]=useState("");

  async function onSearch(){
    const q=(query||"").trim();
    if(!q){ setError("Please enter a search query."); return; }
    setLoading(true); setError("");
    try{
      const data=await getRecommendations({
        query:q, top_k:12,
        max_price:maxPrice?Number(maxPrice):undefined,
        category:category||undefined,
      });
      setResults(Array.isArray(data)?data:[]);
    }catch{
      setError("Could not reach backend at http://localhost:8000. Is it running?");
      setResults([]);
    }finally{ setLoading(false); }
  }
  function onKeyDown(e){ if(e.key==="Enter") onSearch(); }

  return (
    <>
      {/* Sticky header */}
      <div className="header">
        <div className="header-inner row" style={{justifyContent:"space-between"}}>
          <div className="brand">
            <span className="brand-badge" />
            <div>Product Recommender</div>
          </div>
          <Link to="/analytics" className="btn btn-ghost">📊 Analytics</Link>
        </div>
      </div>

      <div className="container">
        {/* Search bar */}
        <div className="row gap-12 section">
          <input className="input" style={{flex:3}} value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={onKeyDown} placeholder="Search products…" />
          <input className="input" style={{width:160}} value={maxPrice} onChange={e=>setMaxPrice(e.target.value)} onKeyDown={onKeyDown} placeholder="Max price (USD)" />
          <input className="input" style={{width:220}} value={category} onChange={e=>setCategory(e.target.value)} onKeyDown={onKeyDown} placeholder="Category" />
          <button className="btn btn-primary" onClick={onSearch} disabled={loading}>
            {loading? "Searching…" : "Search"}
          </button>
        </div>

        {/* CV panel */}
        <div className="card card--pad section">
          <CVPanel />
        </div>

        {/* Errors / states */}
        {error && <div className="card card--pad" style={{borderColor:"rgba(239,68,68,.35)"}}>{error}</div>}
        {loading && <div className="skeleton" style={{height:56, margin:"12px 0"}} />}

        {!loading && !results.length && !error && (
          <div className="muted section">
            No results yet. Try <b>mesh office chair</b> or set a max price.
          </div>
        )}

        {/* Results */}
        <div className="grid-1 section">
          {results.map(r=>{
            const cats=parseCats(r.category);
            const img=firstImageUrl(r.image_url);
            return (
              <div key={r.id} className="card card--pad">
                <div className="row" style={{alignItems:"flex-start"}}>
                  <div className="thumb">
                    {img? <img src={img} alt={r.title} loading="lazy"/> : <span className="muted">No Image</span>}
                  </div>

                  <div style={{flex:1}}>
                    <div className="row" style={{justifyContent:"space-between"}}>
                      <div style={{fontWeight:800,lineHeight:1.25}}>{r.title}</div>
                      <div className="price">{formatUsd(r.price)}</div>
                    </div>

                    <div className="section" style={{margin:6}}>
                      {r.brand && <span className="muted" style={{marginRight:6}}>{r.brand} •</span>}
                      {cats.map(c=> <span key={c} className="pill" style={{marginRight:6}}>{c}</span>)}
                    </div>

                    <div className="muted">{(r.description||"").slice(0,180)}</div>

                    {r.gen_description && (
                      <div className="hint" style={{marginTop:8}}>✨ {r.gen_description}</div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

/* ---------- CV Panel (same logic, prettier UI) ---------- */
function CVPanel(){
  const [file,setFile]=useState(null);
  const [url,setUrl]=useState("");
  const [res,setRes]=useState(null);
  const [err,setErr]=useState("");
  const [loading,setLoading]=useState(false);

  async function onClassifyFile(){
    if(!file){ setErr("Pick an image file first"); return; }
    setLoading(true); setErr(""); setRes(null);
    try{ setRes(await classifyImageBlob(file)); }catch{ setErr("Classification failed"); }
    finally{ setLoading(false); }
  }
  async function onClassifyUrl(){
    if(!url.trim()){ setErr("Enter an image URL"); return; }
    setLoading(true); setErr(""); setRes(null);
    try{ setRes(await classifyImageUrl(url.trim())); }catch{ setErr("Classification failed"); }
    finally{ setLoading(false); }
  }

  return (
    <>
      <div className="row" style={{gap:12, marginBottom:8}}>
        <div className="muted" style={{fontWeight:700}}>🧠 Try Computer Vision (zero-shot)</div>
      </div>
      <div className="row gap-12">
        <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)} className="input input--sm" style={{padding:6}}/>
        <button className="btn btn-primary" onClick={onClassifyFile} disabled={loading}>{loading?"Classifying…":"Classify File"}</button>
        <input className="input" style={{width:320}} value={url} onChange={e=>setUrl(e.target.value)} placeholder="…or paste image URL" />
        <button className="btn btn-primary" onClick={onClassifyUrl} disabled={loading}>{loading?"Classifying…":"Classify URL"}</button>
      </div>

      {err && <div className="card card--pad" style={{marginTop:10, borderColor:"rgba(239,68,68,.35)"}}>{err}</div>}
      {res && (
        <div className="row" style={{marginTop:10}}>
          <span className="muted"><b>Label:</b></span>&nbsp;{res.label}&nbsp;&nbsp;
          <span className="muted"><b>Confidence:</b></span>&nbsp;{Math.round((res.confidence||0)*100)}%
        </div>
      )}
    </>
  );
}
